﻿// See https://aka.ms/new-console-template for more information


//use TryParce(string,out variable)
// out is a required keyward
// variable
// Try parse return bool

const double GasPrice = 1.8;
double distance = 0.0; // is double the best standard?
double fuelCost = 0.0;
double fuelEfficiency = 0.0;
double fuelNeeded = 0.0;
double totalCost = 0.0;
int foodCost = 0;
bool isMyCar = false;
string userChoice = "";
bool nextCalculation = true;

// *Prompt
while (nextCalculation)
{
    Console.Write("\nPlease enter the trip distance in whole kilometers: ");

    while (!(double.TryParse(Console.ReadLine(), out distance) && distance > 0))
    {
        if (distance > 0)
        {
            Console.WriteLine($"you entered {distance}");
        }
        else
        {
            Console.WriteLine($"\nyour entry is invalid (you entered '{distance}'). Try again");
            Console.Write("Please enter the trip distance in whole kilometers again: ");
        }
    }

    Console.Write("Will you be taking [y]our vehicle or your [f]riend's? ");
    userChoice = Console.ReadLine();
    while (!userChoice.ToUpper().Equals("Y") && !userChoice.ToUpper().Equals("F"))
    {
        Console.WriteLine($"\nyour entry is invalid (you entered '{userChoice}'). Try again");
        Console.Write("Will you be taking [y]our vehicle or your [f]riend's? ");
        userChoice = Console.ReadLine();
    }

    if (userChoice.ToUpper().Equals("Y"))
    {
        Console.WriteLine(" you  decided to take your car.");
        isMyCar = true;
    }
    else if (userChoice.ToUpper().Equals("F"))
    {
        Console.WriteLine(" you  decided to take your friend's car.");
        isMyCar = false;
    }
    else
    {
        Console.WriteLine("invalid input, try again");
    }

    //* Process

    if (isMyCar)
    {
        fuelEfficiency = 11.9 / 100;
    }
    else
    {
        fuelEfficiency = 8.7 / 100;
    }
    fuelNeeded = fuelEfficiency * distance;
    fuelCost = fuelNeeded * GasPrice;

    if (distance < 200)
    {
        foodCost = 30;
    }
    else if (distance < 500)
    {
        foodCost = 50;
    }
    else if (distance < 1000)
    {
        foodCost = 80;
    }
    else
    {
        foodCost = 120;
    }
    totalCost = foodCost + fuelCost;

    // *Print

    Console.WriteLine($"\nTrip length:  {distance} km");

    if (isMyCar)
    {
        Console.WriteLine("Fuel efficiency:  11.9 L per 100 km");
    }
    else
    {
        Console.WriteLine("Fuel efficiency:  8.7 L per 100 km");
    }
    Console.WriteLine($"Fuel needed: {fuelNeeded.ToString("F2")} L");
    Console.WriteLine("Fuel price: $1.80 per L");

    Console.WriteLine($"\nFuel cost:      ${fuelCost.ToString("F2")}");
    Console.WriteLine($"Food cost:      ${foodCost.ToString("F2")}");
    Console.WriteLine("----------------------");
    Console.WriteLine($"Total cost:    ${totalCost.ToString("F2")}");

    Console.WriteLine("\nWould you like to do another calculation? ");
    Console.Write("Enter Y to continue or any other key to Exit: ");
    if (!Console.ReadLine().ToUpper().Equals("Y"))
    {
        nextCalculation = false;
    }
}
