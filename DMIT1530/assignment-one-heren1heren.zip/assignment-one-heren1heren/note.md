HTML and css validation
css:
font family
ONLY rem NO px
img must be flexible

after 1440px: text container must be centered
Zip after done
